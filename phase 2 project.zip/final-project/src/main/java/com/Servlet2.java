package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Servlet2")
public class Servlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String source=request.getParameter("source");
		String destination=request.getParameter("destination");
		out.println("<h1>The flight details are</h1>");
		out.println("<table border=2><tr><th>id</th><th>name</th><th>date_of_travel</th><th>source</th><th>destination</th><th>price</th><tr/>");
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/flyaway","root","ThinkPad@66");
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("select * from flyaway.airplane_details where source="+source+"destination="+destination+"");
			
		
			while(rs.next()) {
				out.println("<tr><td>");
				out.println(rs.getString(1));
				out.println("</td>");
				out.println("<td>");
				out.println(rs.getString(2));
				out.println("</td>");
				out.println("<td>");
				out.println(rs.getString(3));
				out.println("</td>");
				out.println("<td>");
				out.println(rs.getString(4));
				out.println("</td>");
				out.println("<td>");
				out.println(rs.getString(5));
				out.println("</td>");
				out.println("<td>");
				out.println(rs.getString(6));
				out.println("</td>");
			}
		}
		catch(Exception e)
		{
		   e.printStackTrace();
		   
		}
		out.println("</table>");
		
		out.println("<a href=http://localhost:8181/final-project/index2.html>Click here for payment</a>");
		
	}

}
