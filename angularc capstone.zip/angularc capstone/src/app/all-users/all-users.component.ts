import { analyzeAndValidateNgModules } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-all-users',
  templateUrl: './all-users.component.html',
  styleUrls: ['./all-users.component.css']
})
export class AllUsersComponent implements OnInit {

  constructor(private service:UserServiceService) { }
  name="";
  password:any
  users:any;
  invalid_msg="";
  valid_msg:any
  ngOnInit(): void {
  }
  public validate()
  {
    if((this.name=="satya")&&(this.password=="ThinkPad@66"))
    {
      this.valid_msg="You logged into a secure area"
      let response=this.service.doadmin();
      response.subscribe(data => {
        this.users=data;
      })
           
    }
    else{
     // alert("enter correct details");
      this.invalid_msg="Enter valid details";
    }
  }
  msg:any
  public remove(acc_no)
  {  
    console.log(acc_no);
    let response=this.service.doremove(acc_no);
    response.subscribe(data => {
      this.msg=data;
    })
  }

}
