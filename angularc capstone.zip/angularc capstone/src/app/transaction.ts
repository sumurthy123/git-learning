export class Transaction{
  constructor(
    public sender_acc_no,
    public amount,
    public password,
    public receiver_acc_no

    ){}
}