export class User
{
    constructor(
       public acc_no:number,
        public name:string,
        public password:number,
        public cash:number,
       public contact:number
    ){}

}